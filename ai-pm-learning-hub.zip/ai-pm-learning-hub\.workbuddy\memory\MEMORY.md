# AI PM 学习平台 - 长期记忆

## 项目定位
- AI PM 学习平台，每周自动生成学习内容和测试题
- 自动化任务 ID: ai-pm-2（每周日 9:00 执行）

## 内容方向演进
- **2026-03-23**：通用 AI PM / Agent 方向
- **2026-04-09 起**：**转型为 AI 客服方向产品策划**主线
  - 核心技术栈：Transformer 架构 → LoRA/QLoRA 微调 → RAG 知识库检索 → AI 客服系统落地
  - 用户提供了两张关键架构图作为内容锚点：
    1. Transformer 完整架构详解图（含 Self-Attention、FFN、编码器-解码器、采样策略）
    2. 模型微调白板笔记（LoRA 参数、Prompt/System/人设/知识库/RAG、LLaMA 7B、超参调优）

## 用户背景关联
- Victor 正在做 GameColla 项目转型 + 超核专属 Agent/Botler 开发
- AI 客服方向与超核 Agent/Botler 的知识库+对话能力高度相关
- 已有 FastMCP (uv) 搭建 demo server tools 经验

*创建于 2026-04-09*
